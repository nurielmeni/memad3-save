version 1.1.1
=============
**Date:** 03-May-2015

- enh #4: Upgrade extension to use latest release & features of bootstrap-notify plugin.

version 1.1.0
=============
**Date:** 10-Nov-2014

- bug #1: Correct AnimateAsset dependency
- set stability to stable


version 1.0.0
=============
**Date:** 08-Nov-2014

- Initial release 
- Sub repo split from [yii2-widgets](https://github.com/kartik-v/yii2-widgets)