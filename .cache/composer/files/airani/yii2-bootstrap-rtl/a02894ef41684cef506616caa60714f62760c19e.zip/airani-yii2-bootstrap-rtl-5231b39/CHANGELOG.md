Yii Framework 2 bootstrap rtl extension Change Log
==================================================

1.0 March 23, 2015
------------------

- Initial release.
